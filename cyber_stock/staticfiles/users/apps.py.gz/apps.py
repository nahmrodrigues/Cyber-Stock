from django.apps import AppConfig

class UsersAppConfig(AppConfig):
  verbose_name = "Users"
  name = "users"