from django.apps import AppConfig

class ProductsAppConfig(AppConfig):
  verbose_name = "Products"
  name = "products"